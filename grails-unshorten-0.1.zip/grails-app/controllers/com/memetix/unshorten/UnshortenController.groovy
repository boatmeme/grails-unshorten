package com.memetix.unshorten

/**
 * UnshortenController provides an example / test implementation of the Unshorten plugin
 * 
 * It takes a single parameter (params.shortLink) and passes it to unshortenService.unshorten()
 * Then, it hands the result back to the index view and displays it.
 * 
 * @author Jonathan Griggs  <twitcaps.developer @ gmail.com>
 * @version     2011.0516                                
 * @since       Grails 1.3.7                            
 */
class UnshortenController {
    def unshortenService

    def index = { 
        
    }
    
    def unshorten = {
        render(view:"index",model:[fullLink: unshortenService.unshorten(params.shortLink)])
    }
}
