package com.memetix.unshorten
import org.codehaus.groovy.grails.commons.ConfigurationHolder

/**
 * UnshortenService provides services that take shortened URLs as input: 
 * 
 *      [http://t.co/8lrqrZf, http://tinyurl.com/3vy9xga, http://bit.ly/jkD0Qr] for example 
 *  
 * And returns the corresponding expanded, original URLs
 * 
 * There is a service unshorten(), for single links that returns a single String representing the expanded URL
 * There is a service unshortenAll(), which is used for lists of shortened URLs. It returns a Map with expanded URL values keyed by the shortened url
 * 
 * The UnshortenService encapsulates a Thread-safe LRU Cache with a configurable maxSize that defaults to 10000. Unshortened/Expanded Links 
 * are stored as Strings in the cache, keyed by the Shortened version of the URL
 * 
 * @author Jonathan Griggs  <twitcaps.developer @ gmail.com>
 * @version     2011.0516                                
 * @since       Grails 1.3.7                            
 */

class UnshortenService {
    static transactional = false
    def maxCacheSize = ConfigurationHolder.config.unshorten.cache.maxSize ?: 10000
    def cache = new LRUCache(maxCacheSize)
    static scope = "singleton"

    /**
     * unshorten()                         
     *
     * Takes a shortened string and gives you back the expanded string
     * 
     * If the linkString parameter matches the expanded version, then the normalized version of the original linkString is returned.
     * If the linkString parameter is an invalid URL, then location is null
     * 
     * This method will first attempt to load the expanded URL from the LRUCache. If the linkString matches the expanded version, the
     * result is not stored in the cache.
     *
     * @param  linkString A string representing a shortened URL (i.e. http://bit.ly/jkD0Qr)           
     * @return A String representing the expanded, original URL
     */
    def unshorten(linkString) {
        def link = linkString
        
        if(!link.toLowerCase().contains("http://")) {
            link = "http://${link}"
        }
        
        def location = cache.get(link)
        
        if(location)
            return location
        
        try {
            def url = new URL(link)
            URLConnection urlc = url.openConnection();
            urlc.setRequestMethod("HEAD");
            urlc.setInstanceFollowRedirects( false );
            urlc.connect()
            def responseCode = urlc.getResponseCode();

            if(responseCode==200)
                return link

            if(responseCode==301) {
                location = urlc.getHeaderField("Location");
                if(link!=location&&location) {
                    cache.put(link,location)
                }
            }
        } catch (Exception e) {
            log.debug "Error Unshortening URL ${linkString}: ${e}"
        }
        
        return location
    }

    /**
     * unshortenAll()                         
     *
     * Takes a list of strings representing shortened urls and gives you back the expanded strings in a Map keyed by the shortened URL
     * 
     * This method can take a single String object OR a list of Strings. The return value is always a map of Expanded String values
     * keyed by the shortened URLs
     *
     * @param  list A list of strings representing 1 - n shortened URLs (i.e. http://bit.ly/jkD0Qr)           
     * @return A Map representing the list of expanded, original URLs, keyed by the shortened URLs
     */
    
    def unshortenAll(list) {
       def returnMap = new HashMap()
       for(link in asList(list)) {
           def fullLink = unshorten(link)
           if(fullLink) {
            returnMap.put(link,fullLink)
           }
       } 
       return returnMap
    }
    /**
     * asList()
     * 
     * Private helper method that flattens a list. This is useful because it will take lists of lists, or even a single object
     * and return everything in one list.
     * 
     * Mostly useful for the case of dealing with a single object and wrapping it in a list.
    */
    private asList(orig) {
        return [orig].flatten()
    }
}
